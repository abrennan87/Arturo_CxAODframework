#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ nestedclass;

/* Add a pragma link for any EventLoop algorithm */
#endif

/*This was automatically inserted by xAH_scaffold.py*/
#include <xAODHelpers/WTaggedHistsAlgo.h>
#ifdef __CINT__
#pragma link C++ class WTaggedHistsAlgo+;
#endif
/*This was automatically inserted by xAH_scaffold.py*/
