# BosonTaggerXAOD - A RootCore Package

## Installing
The last stable analysis base used is **2.0.27**. To install,
```bash
mkdir myRootCore && cd myRootCore
rcSetup Base,2.0.27
git clone https://github.com/kratsg/BosonTaggerXAOD.git
rc find_packages
rc compile
test_taggerExample
```

### Functionality Included

#### Example Usage

#### Authors
- [Giordon Stark](https://github.com/kratsg)

#### Acknowledgements
- Thanks to Samuel Meehan, Reina Camacho.
