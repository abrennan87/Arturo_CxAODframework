#include <EventLoop/Job.h>
#include <EventLoop/StatusCode.h>
#include <EventLoop/Worker.h>
#include <BosonTaggerXAOD/WTagger.h>

// c++ includes
#include <iostream>
#include <sstream>
#include <fstream>

// local includes
#include <BosonTaggerXAOD/tools/ReturnCheck.h>
#include <BosonTaggerXAOD/tools/ReturnCheckConfig.h>
#include <BosonTaggerXAOD/HelperFunctions.h>

// framework includes
#include <xAODJet/JetContainer.h>
#include <xAODEventInfo/EventInfo.h>

// root includes
#include <TEnv.h>
#include <TSystem.h>

// this is needed to distribute the algorithm to the workers
ClassImp(WTagger)

WTagger :: WTagger () {}

EL::StatusCode WTagger :: setupJob (EL::Job& job)
{
  job.useXAOD();
  xAOD::Init("WTagger").ignore();
  return EL::StatusCode::SUCCESS;
}

EL::StatusCode WTagger :: configure ()
{
  Info("configure()", "Running configure()");
  m_configName = gSystem->ExpandPathName( m_configName.c_str() );
  RETURN_CHECK_CONFIG("WTagger::configure()", m_configName);

  // the file exists, use TEnv to read it off
  TEnv* config = new TEnv(m_configName.c_str());
  m_inContainerName         = config->GetValue("InputContainer",  "");
  m_recommendationsFile     = config->GetValue("RecsFile", "");
  m_debug                   = config->GetValue("Debug", false);
  m_workingPoint            = config->GetValue("WorkingPoint", "medium");
  m_tagger                  = config->GetValue("Tagger", "tau21");
  m_massCompare             = config->GetValue("MassCompare", false);
  m_varCompare              = config->GetValue("VarCompare", false);
  m_simpleTagger            = config->GetValue("SimpleTagger", false);
  m_decorationName          = config->GetValue("DecorationName", "wtag");
  // input values
  // m_tau21                   = config->GetValue("Tau21", 0.0);
  m_c2beta1                 = config->GetValue("C2Beta1", 0.0);
  m_d2beta1                 = config->GetValue("D2Beta1", 0.0);

  if( m_inContainerName.empty() ){
    Error("configure()", "No InputContainer specified!");
    return EL::StatusCode::FAILURE;
  }

  if( m_recommendationsFile.empty() ){
    Error("configure()", "No configuration file specified!");
    return EL::StatusCode::FAILURE;
  }

  std::set<std::string> validWorkingPoints;
  validWorkingPoints.insert("tight");
  validWorkingPoints.insert("medium");
  validWorkingPoints.insert("loose");
  validWorkingPoints.insert("veryloose");

  std::set<std::string> validTaggers;
  validTaggers.insert("tau21");
  validTaggers.insert("c2beta1");
  validTaggers.insert("d2beta1");
  validTaggers.insert("twovar");

  if( validWorkingPoints.find(m_workingPoint) == validWorkingPoints.end()){
    Error("configure()", "Unknown working point requested %s!", m_workingPoint.c_str());
    return EL::StatusCode::FAILURE;
  }

  if( validTaggers.find(m_tagger) == validTaggers.end()){
    Error("configure()", "Unknown taggger requested %s!", m_tagger.c_str());
    return EL::StatusCode::FAILURE;
  }

  if( !(m_massCompare|m_varCompare) ){ // at least one must be set to true
    Error("configure()", "Both MassCompare and VarCompare cannot be false!");
    return EL::StatusCode::FAILURE;
  }

  // these raise warnings but are not catastrophic...
  // if( m_tau21 == 0.0 ) Warning("configure()", "Tau21 is set to 0.0");
  if( m_c2beta1 == 0.0 ) Warning("configure()", "C2Beta1 is set to 0.0");
  if( m_d2beta1 == 0.0 ) Warning("configure()", "D2Beta1 is set to 0.0");

  /* everything seems to have a good initial configuration, let's read in the config file */
  m_recommendationsFile = gSystem->ExpandPathName(m_recommendationsFile.c_str());
  RETURN_CHECK_CONFIG("WTagger::configure()", m_recommendationsFile);
  std::ifstream f_in;
  f_in.open(m_recommendationsFile, std::ios::in);
  if( f_in.fail() ){
    Error("configure()", "Something is wrong with the recommendations file. Could not open for reading.");
    return EL::StatusCode::FAILURE;
  }
  std::string line;
  while( std::getline(f_in, line) ){
    /* token contains the current splitted text */
    std::string token;

    if(m_debug) Info("configure()", "Reading in line: %s", line.c_str());

    /* notes, one should add a check on all values to make sure they are valid! */

    // split by space
    std::istringstream ss(line);
    /* lineDetails is an array of the splits */
    std::vector<std::string> lineDetails{std::istream_iterator<std::string>{ss}, std::istream_iterator<std::string>{}};

    std::string workingPoint = lineDetails[0];
    std::string tagger          = lineDetails[3];
    std::string algorithm       = lineDetails[1];
    // might need to do std::stoi(lineDetails[2].substr(2,5).c_str())
    double ptbin                = std::stoi(lineDetails[2].substr(2,5).c_str());

    CONFIG newConfig = {};
    newConfig.cut_low   = std::stod(lineDetails[4]);
    newConfig.cut_high  = std::stod(lineDetails[5]);
    newConfig.var_dir   = lineDetails[6];
    newConfig.var_cut   = std::stod(lineDetails[7]);
    if(lineDetails.size() == 9) newConfig.twovar_signalregion_filepath = lineDetails[8];

    m_configurations[workingPoint][tagger][algorithm][ptbin] = newConfig;

    if(m_debug) Info("configure()", "Parsed line as: %s | %s | %0.2f | %s | %0.2f | %0.2f | %s | %0.2f | %s",
                      workingPoint.c_str(), algorithm.c_str(), ptbin, tagger.c_str(), newConfig.cut_low, newConfig.cut_high,
                      newConfig.var_dir.c_str(), newConfig.var_cut, newConfig.twovar_signalregion_filepath.c_str());
  }

  if(m_debug) config->Print();
  delete config;

  return EL::StatusCode::SUCCESS;
}


EL::StatusCode WTagger :: histInitialize ()
{
  Info("histInitialize()", "Calling configure()");
  if( this->configure() == EL::StatusCode::FAILURE ){
    Error("histInitialize()", "Failed to properly configure. Exiting.");
    return EL::StatusCode::FAILURE;
  }

  return EL::StatusCode::SUCCESS;
}

EL::StatusCode WTagger :: fileExecute () { return EL::StatusCode::SUCCESS; }
EL::StatusCode WTagger :: changeInput (bool /*firstFile*/) { return EL::StatusCode::SUCCESS; }
EL::StatusCode WTagger :: initialize ()
{
  if(m_debug) Info("initialize()", "Initializing TEvent and TStore");
  m_event = wk()->xaodEvent();
  m_store = wk()->xaodStore();
  return EL::StatusCode::SUCCESS;
}

EL::StatusCode WTagger :: execute ()
{
  const xAOD::EventInfo* eventInfo(0);
  const xAOD::JetContainer* inJets(0);
  RETURN_CHECK("WTagger::execute()", HelperFunctions::retrieve(eventInfo, "EventInfo", m_event, m_store, m_debug), "");
  RETURN_CHECK("WTagger::execute()", HelperFunctions::retrieve(inJets, m_inContainerName, m_event, m_store, m_debug), "");

  // pull in the accessors to classify the jet algorithm
  int numTaggedInEvent = 0;

  /* Jet algorithm (0=Kt, 1=CamKt, 2=AntiKt) */
  static SG::AuxElement::ConstAccessor<int> AlgorithmType ("AlgorithmType");
  static std::map<int, std::string> mapAlgorithmType = {
    {0, "KT"},
    {1, "CA"},
    {2, "AK"}
  };

  /* Jet size parameter (radius) */
  static SG::AuxElement::ConstAccessor<float> SizeParameter ("SizeParameter");

  /* Input (0=LCTopo, 1=EMTopo, 4=truth, 5=track, 6=pflow)*/
  static SG::AuxElement::ConstAccessor<int> InputType ("InputType");
  static std::map<int, std::string> mapInputType {
    {0, "LC"},
    {1, "EM"},
    {4, "TRU"},
    {5, "TRA"},
    {6, "PFL"}
  };

  /* Grooming flag (1=trimming, 2=pruning, 3=splitting) */
  static SG::AuxElement::ConstAccessor<int> TransformType ("TransformType");
  static std::map<int, std::string> mapTransformType {
    {2, "TRIM"},
    {3, "PRUN"},
    {4, "BDRS"}
  };

  // for trimming
  static SG::AuxElement::ConstAccessor<float> RClus ("RClus");
  static SG::AuxElement::ConstAccessor<float> PtFrac ("PtFrac");

  // for pruning
  static SG::AuxElement::ConstAccessor<float> RCut ("RCut");
  static SG::AuxElement::ConstAccessor<float> ZCut ("ZCut");

  // for splitting
  // static SG::AuxElement::ConstAccessor<int> NSubjetMax ("NSubjetMax");
  static SG::AuxElement::ConstAccessor<char> BDRS ("BDRS");
  /* MuMax, YMin, RClus */
  // static SG::AuxElement::ConstAccessor<float> RClus ("RClus"); // defined above for trimming
  static SG::AuxElement::ConstAccessor<float> YMin ("YMin");
  static SG::AuxElement::ConstAccessor<float> MuMax ("MuMax");

  // for tau21
  static SG::AuxElement::ConstAccessor<float> Tau1 ("Tau1");
  static SG::AuxElement::ConstAccessor<float> Tau2 ("Tau2");

  // pass WTag decoration
  static SG::AuxElement::Decorator<char> passTagDecor(m_decorationName);
  // num WTags decoration
  static SG::AuxElement::Decorator<int> numTagDecor("num_"+m_decorationName);


  // initialize a lot of variables up here
  CONFIG configParameters;
  double variableValue;
  double tau21;
  bool isWTagged;
  int jet_algorithmType, jet_inputType, jet_transformType;
  std::string algorithmName;

  // set number of wtags in event to 0, set this after loop
  numTagDecor(*eventInfo) = 0;
  if(m_debug) Info("execute()", "Processing run %u, event %llu", eventInfo->runNumber(), eventInfo->eventNumber());
  for(const auto jet: *inJets){
    if(m_debug) Info("execute()", "Pt: %0.2f\tM: %0.2f\tEta: %0.2f\tPhi: %0.2f", jet->pt(), jet->m(), jet->eta(), jet->phi());
    /* assume it does not pass */
    isWTagged = false;
    passTagDecor(*jet) = isWTagged;
    // we do not want to tag such jets with Pt=0.0
    if(int(jet->pt()/1000.) == 0){Warning("execute()", "Encountered an invalid jet in event %llu, skipping.", eventInfo->eventNumber()); continue;}

    // TODO: potentially fix it up in a way that we compute the algorithm name only once
    //          and store it for accessing in future calls of execute() if we are slow now

    // determine the algorithm string for matching to the config file
    jet_algorithmType = jet_inputType = jet_transformType = 0;
    if( !AlgorithmType.isAvailable(*jet) ){ Warning("execute()", "AlgorithmType is not defined for the input jet."); continue;}
    if( !InputType.isAvailable(*jet) )    { Warning("execute()", "InputType is not defined for the input jet."); continue;}
    if( !TransformType.isAvailable(*jet) ){ Warning("execute()", "TransformType is not defined for the input jet."); continue;}
    // all three are set above, grab the values
    jet_algorithmType = AlgorithmType(*jet);
    jet_inputType = InputType(*jet);
    jet_transformType = TransformType(*jet);
    // start writing it
    algorithmName = mapAlgorithmType[jet_algorithmType]
                    + std::to_string(static_cast<int>(SizeParameter(*jet)*10))
                    + mapInputType[jet_inputType]
                    + mapTransformType[jet_transformType];

    if(m_debug) Info("execute()", "Algorithm Type: %s\tSize Parameter: %s\tInput Type: %s\tTransform Type: %s",
                      mapAlgorithmType[jet_algorithmType].c_str(),
                      std::to_string(static_cast<int>(SizeParameter(*jet)*10)).c_str(),
                      mapInputType[jet_inputType].c_str(),
                      mapTransformType[jet_transformType].c_str());

    switch(jet_transformType){
      case 2:
        if( !PtFrac.isAvailable(*jet) ){ Warning("execute()", "PtFrac is not defined for the input jet."); continue; }
        if( !RClus.isAvailable(*jet) ){ Warning("execute()", "RClus is not defined for the input jet."); continue; }
        if(m_debug) Info("execute()", "PtFrac: %0.2f\tRClus: %0.2f", PtFrac(*jet), RClus(*jet));
        algorithmName += "F" + std::to_string(static_cast<int>(PtFrac(*jet)*100))
                         + "R" + std::to_string(static_cast<int>(RClus(*jet)*100));
      break;
      case 3:
        if( !RCut.isAvailable(*jet) ){ Warning("execute()", "RCut is not defined for the input jet."); continue; }
        if( !ZCut.isAvailable(*jet) ){ Warning("execute()", "ZCut is not defined for the input jet."); continue; }
        if(m_debug) Info("execute()", "RCut: %0.2f\tZCut: %0.2f", RCut(*jet), ZCut(*jet));
        algorithmName += "R" + std::to_string(static_cast<int>(RCut(*jet)*100))
                         + "Z" + std::to_string(static_cast<int>(ZCut(*jet)*100));
      break;
      case 4:
        if( !MuMax.isAvailable(*jet) ){ Warning("execute()", "MuMax is not defined for the input jet."); continue; }
        if( !RClus.isAvailable(*jet) ){ Warning("execute()", "RClus is not defined for the input jet."); continue; }
        if( !YMin.isAvailable(*jet) ){ Warning("execute()", "YMin is not defined for the input jet."); continue; }
        if( !BDRS.isAvailable(*jet) ){ Warning("execute()", "BDRS is not defined for the input jet."); continue; }
        // std::cout << BDRS(*jet) << " | " << (BDRS(*jet) == true) << std::endl;
        if(m_debug) Info("execute()", "MuMax: %0.2f\tRClus: %0.2f\tYMin: %0.2f", MuMax(*jet), RClus(*jet), YMin(*jet));
        algorithmName += "M" + std::to_string(static_cast<int>(MuMax(*jet)*100))
                         + "R" + std::to_string(static_cast<int>(RClus(*jet)*100))
                         + "Y" + std::to_string(static_cast<int>(YMin(*jet)*100));
      break;
    }
    // next, get the ptbin
    double ptbin(0.0);
    double jetPt(jet->pt()/1000.);
    // set ptbin to 200 if using the "simple" tagger option
    if(m_simpleTagger) ptbin = 200.0;
    else {
      if      (jetPt > 200.0  && jetPt < 350.0 ) ptbin =  200.0;
      else if (jetPt > 350.0  && jetPt < 500.0 ) ptbin =  350.0;
      else if (jetPt > 500.0  && jetPt < 1000.0) ptbin =  500.0;
      else if (jetPt > 1000.0 && jetPt < 1500.0) ptbin = 1000.0;
      else if (jetPt > 1500.0 && jetPt < 2000.0) ptbin = 1500.0;
      //else if (jetPt > 2000.0 && jetPt < 3000.0) ptbin = 2000.0;
      else ptbin = 200.0;
    }

    if(m_debug) Info("execute()", "PtBin: %0.2f", ptbin);

    // after all the random initializations, grab the correct configuration
    if( !m_configurations.count(m_workingPoint) ){
      Error("execute()", "Could not find workingPoint %s", m_workingPoint.c_str());
      return EL::StatusCode::FAILURE;
    }
    if( !m_configurations[m_workingPoint].count(m_tagger) ){
      Error("execute()", "Could not find tagger %s", m_tagger.c_str());
      return EL::StatusCode::FAILURE;
    }
    if( !m_configurations[m_workingPoint][m_tagger].count(algorithmName) ){
      Error("execute()", "Could not find algorithm %s", algorithmName.c_str());
      return EL::StatusCode::FAILURE;
    }
    if( !m_configurations[m_workingPoint][m_tagger][algorithmName].count(ptbin) ){
      Error("execute()", "Could not find ptbin %0.2f", ptbin);
      return EL::StatusCode::FAILURE;
    }
    /* if we made it here, we have a valid combination of:
       - algorithm type
       - input type
       - grooming type
      and we have definitions for it in the configuration file being passed in.
    */
    if(m_debug) Info("execute()", "Found the correct configuration parameters for the jet.");
    configParameters = m_configurations[m_workingPoint][m_tagger][algorithmName][ptbin];

    // calculate tau21
    tau21 = 0.0;
    if(!Tau1.isAvailable(*jet) || !Tau2.isAvailable(*jet)) Warning("execute()", "Tau1 or Tau2 are not available!.");
    else tau21 = Tau2(*jet)/Tau1(*jet);

    if(m_tagger == "tau21"){
      variableValue = tau21;
    } else if(m_tagger == "c2beta1"){
      variableValue = m_c2beta1;
    } else if(m_tagger == "d2beta1"){
      variableValue = m_d2beta1;
    } else if(m_tagger == "twovar"){
      variableValue = configParameters.getTwoVar(m_d2beta1, tau21);
    } else {
      variableValue = 0.0;
      Error("execute()", "variableValue is set to 0.0. This is a logic bug. Report it to appropriate person(s).");
      return EL::StatusCode::FAILURE;
    }

    // figure out if we tag or not
    bool massCompare = (jet->m()/1000. > configParameters.cut_low && jet->m()/1000. < configParameters.cut_high);
    bool variableCompare = configParameters.compareVariable(variableValue);
    if( m_massCompare & ~m_varCompare) isWTagged = massCompare;
    if(~m_massCompare &  m_varCompare) isWTagged = variableCompare;
    if( m_massCompare &  m_varCompare) isWTagged = massCompare&variableCompare;

    // now decorate! Note: store as a char for retrieval later
    passTagDecor(*jet) = isWTagged;

    numTaggedInEvent += isWTagged;
  }

  // set number of wtags in event
  numTagDecor(*eventInfo) = numTaggedInEvent;
  if(m_debug) Info("execute()", "We tagged %d/%lu jets as W bosons.\n\n", numTaggedInEvent, inJets->size());

  return EL::StatusCode::SUCCESS;
}

EL::StatusCode WTagger :: postExecute () { return EL::StatusCode::SUCCESS; }
EL::StatusCode WTagger :: finalize () { return EL::StatusCode::SUCCESS; }
EL::StatusCode WTagger :: histFinalize () { return EL::StatusCode::SUCCESS; }
