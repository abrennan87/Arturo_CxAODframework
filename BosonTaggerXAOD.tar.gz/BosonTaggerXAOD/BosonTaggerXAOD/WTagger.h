#ifndef BosonTaggerXAOD_WTagger_H
#define BosonTaggerXAOD_WTagger_H

// framework includes
#include <string>
#include <set>

// package includes
#include <EventLoop/Algorithm.h>

// framework includes
#include "xAODRootAccess/Init.h"
#include "xAODRootAccess/TEvent.h"
#include "xAODRootAccess/TStore.h"

// root includes
#include <TFile.h>
#include <TH2F.h>

class WTagger : public EL::Algorithm
{
public:

  /* path to configuration file specifying everything */
  std::string m_configName;

private:
  /* grab event data and store it for other algs */
  xAOD::TEvent *m_event; //!
  xAOD::TStore *m_store; //!

  // configuration variables

  /* container to use for tagging */
  std::string m_inContainerName; //!
  /* the configuration file containing all the working point information */
  std::string m_recommendationsFile; //!

  /* turn on verbose outputting or not */
  bool m_debug; //!
  /* the working point: loose, medium, tight */
  std::string m_workingPoint; //!
  /* the tagger to use: tau21, c2beta1, d2beta1, twovar */
  std::string m_tagger; //!
  /* mass and var flag: mass, var, massvar */
  bool m_massCompare; //!
  bool m_varCompare; //!
  /* enable "simple" tagger option */
  bool m_simpleTagger; //!
  /* name of decoration to use */
  std::string m_decorationName; //!
  /* variables passed in via config */
  // double m_tau21;
  double m_c2beta1; //!
  double m_d2beta1; //!

  /* struct holding the configuration details read in from the file */
  struct CONFIG {
    double cut_low = 0.0;
    double cut_high = 0.0;
    double var_cut = 0.0;
    std::string var_dir = "";
    std::string twovar_signalregion_filepath = "";
    TFile* twovar_signalregion_file = nullptr;
    TH2* twovar_signalregion_hist = nullptr;

    void openFile(){
      if(!twovar_signalregion_file){
        twovar_signalregion_file = TFile::Open(twovar_signalregion_filepath.c_str());
      }
    }

    void openHist(){
      if(!twovar_signalregion_hist){
        if(!twovar_signalregion_file) openFile();
        twovar_signalregion_hist = (TH2*)twovar_signalregion_file->Get("SignalRegion");
      }
    }

    double getTwoVar(double d2beta1, double tau21){
      if(!twovar_signalregion_hist) openHist();
      int binX = twovar_signalregion_hist->GetXaxis()->FindBin(d2beta1);
      int binY = twovar_signalregion_hist->GetYaxis()->FindBin(tau21);
      return static_cast<double>(twovar_signalregion_hist->GetBinContent(binX, binY) == 1);
    }

    bool compareVariable(double variableValue){
      if(var_dir != "LEFT" && var_dir != "RIGHT") return false;
      return !((variableValue < var_cut)^(var_dir == "LEFT"));
    }

    ~CONFIG() {
      if(twovar_signalregion_file){
        delete twovar_signalregion_file;
        twovar_signalregion_file = nullptr;
      }
      if(twovar_signalregion_hist){
        delete twovar_signalregion_hist;
        twovar_signalregion_hist = nullptr;
      }
    }
  };

  /* map<workingPoint,
         map<tagger,
             map<algorithm,
                 map<ptbin, CONFIG>
                >
            >
        >
  */
  // use (fastjet::JetAlgorithm) jet->getAlgorithmType() later
  // #include <fastjet/JetDefinition.hh>
  std::map<std::string, std::map<std::string, std::map<std::string, std::map<double, CONFIG>>>> m_configurations; //!

public:

  // this is a standard constructor
  WTagger ();

  // these are the functions inherited from Algorithm
  virtual EL::StatusCode setupJob (EL::Job& job);
  virtual EL::StatusCode fileExecute ();
  virtual EL::StatusCode histInitialize ();
  virtual EL::StatusCode changeInput (bool firstFile);
  virtual EL::StatusCode initialize ();
  virtual EL::StatusCode execute ();
  virtual EL::StatusCode postExecute ();
  virtual EL::StatusCode finalize ();
  virtual EL::StatusCode histFinalize ();

  // these are the functions not inherited from Algorithm
  virtual EL::StatusCode configure();
  void setConfig(std::string configName){ m_configName = configName; }

  // this is needed to distribute the algorithm to the workers
  ClassDef(WTagger, 1);
};

#endif
